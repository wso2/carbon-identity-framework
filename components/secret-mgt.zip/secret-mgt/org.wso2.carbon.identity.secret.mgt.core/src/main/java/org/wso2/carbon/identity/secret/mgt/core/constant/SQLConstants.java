package org.wso2.carbon.identity.secret.mgt.core.constant;

/**
 * This class contains database queries related to secret management CRUD operations.
 */
public class SQLConstants {

    public static final String INSERT_SECRET = "INSERT INTO IDN_SECRET( ID, TENANT_ID, NAME, VALUE, " +
            "CREATED_TIME, LAST_MODIFIED ) VALUES(?, ?, ?, ?, ?, ?)";

    public static final String UPDATE_SECRET =
            "UPDATE IDN_SECRET SET NAME = ?,VALUE = ?, LAST_MODIFIED = ? WHERE ID = ?";

    public static final String GET_SECRET_BY_NAME = "SELECT ID,TENANT_ID,NAME,CREATED_TIME, LAST_MODIFIED FROM IDN_SECRET WHERE NAME = ? AND " +
            "TENANT_ID = ? ";

    public static final String GET_SECRET_NAME_BY_ID = "SELECT NAME FROM IDN_SECRET WHERE ID = ? AND " +
            "TENANT_ID = ?";

    public static final String GET_SECRET_BY_ID = "SELECT ID,TENANT_ID,NAME,CREATED_TIME, LAST_MODIFIED FROM" +
            " IDN_SECRET WHERE ID = ? AND TENANT_ID = ? ";

    public static final String GET_SECRET_CREATED_TIME_BY_NAME = "SELECT CREATED_TIME FROM IDN_SECRET " +
            "WHERE NAME = ? AND TENANT_ID = ?";

    public static final String DELETE_SECRET = "DELETE FROM IDN_SECRET WHERE NAME = ? AND TENANT_ID = ?";

    public static final String DELETE_SECRET_BY_ID = "DELETE FROM IDN_SECRET WHERE ID = ? AND " +
            "TENANT_ID = ?";

    public static final String GET_SECRETS =
            "SELECT IDN_SECRET.ID, IDN_SECRET.TENANT_ID, IDN_SECRET.NAME, " +
                    "IDN_SECRET.VALUE, IDN_SECRET.LAST_MODIFIED, IDN_SECRET.CREATED_TIME " +
                    "FROM IDN_SECRET WHERE IDN_SECRET.TENANT_ID = ?";
}
