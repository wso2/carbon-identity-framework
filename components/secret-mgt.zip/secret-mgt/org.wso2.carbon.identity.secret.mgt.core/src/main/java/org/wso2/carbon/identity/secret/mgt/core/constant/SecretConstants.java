/*
 * Copyright (c) 2021, WSO2 Inc. (http://www.wso2.com).
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.carbon.identity.secret.mgt.core.constant;

/**
 * Constants related to configuration management.
 */
public class SecretConstants {

    public static final String DB_SCHEMA_COLUMN_NAME_ID = "ID";
    public static final String DB_SCHEMA_COLUMN_NAME_VALUE = "VALUE";
    public static final String DB_SCHEMA_COLUMN_NAME_NAME = "NAME";
    public static final String DB_SCHEMA_COLUMN_NAME_TENANT_ID = "TENANT_ID";
    public static final String DB_SCHEMA_COLUMN_NAME_LAST_MODIFIED = "LAST_MODIFIED";
    public static final String DB_SCHEMA_COLUMN_NAME_CREATED_TIME = "CREATED_TIME";

    public enum ErrorMessages {
        ERROR_CODE_UNEXPECTED("SECRETM_00001", "Unexpected Error"),
        ERROR_CODE_GET_DAO("SECRETM_00002", "No %s are registered."),
        ERROR_CODE_SECRET_ADD_REQUEST_INVALID("SECRETM_00003", "Secret add request validation failed. " +
                "Invalid secret add request."),
        ERROR_CODE_SECRET_GET_REQUEST_INVALID("SECRETM_00004", "Secret get request validation failed"),
        ERROR_CODE_GET_SECRET("SECRETM_00005", "Error while getting the secret : %s."),
        ERROR_CODE_SECRET_ALREADY_EXISTS("SECRETM_00006", "Secret with the name: %s already exists."),
        ERROR_CODE_ADD_SECRET("SECRETM_00007", "Error while adding the secret : %s."),
        ERROR_CODE_SECRET_DELETE_REQUEST_REQUIRED("SECRETM_00008", "Secret delete request validation failed. " +
                "Invalid secret delete request."),
        ERROR_CODE_SECRET_DOES_NOT_EXISTS("SECRETM_00009", "Secret with the name: %s does not exists."),
        ERROR_CODE_SECRETS_DOES_NOT_EXISTS("SECRETM_00010", "Secrets does not exists."),
        ERROR_CODE_SECRET_REPLACE_REQUEST_INVALID("SECRETM_00011", "Secret replace request validation failed."),
        ERROR_CODE_REPLACE_SECRET("SECRETM_00012", "Error while replacing the secret : %s."),
        ERROR_CODE_SECRET_ID_DOES_NOT_EXISTS("SECRETM_00013", "Secret with the id: %s does not exists."),
        ERROR_CODE_INVALID_SECRET_ID("SECRETM_00014", "Invalid secret id: %s."),
        ERROR_CODE_DELETE_SECRET("SECRETM_00015", "Error while deleting the secret: %s.");

        private final String code;
        private final String message;

        ErrorMessages(String code, String message) {

            this.code = code;
            this.message = message;
        }

        public String getCode() {

            return code;
        }

        public String getMessage() {

            return message;
        }

        @Override
        public String toString() {

            return code + ":" + message;
        }
    }
}
