/*
 * Copyright (c) 2021, WSO2 Inc. (http://www.wso2.com).
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.carbon.identity.secret.mgt.core.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.identity.secret.mgt.core.constant.SecretConstants;
import org.wso2.carbon.identity.secret.mgt.core.exception.SecretManagementClientException;
import org.wso2.carbon.identity.secret.mgt.core.exception.SecretManagementServerException;
import org.wso2.carbon.identity.secret.mgt.core.internal.SecretManagerComponentDataHolder;

import java.util.UUID;

public class SecretUtils {

    private static final Log log = LogFactory.getLog(SecretUtils.class);

    /**
     * This method can be used to generate a SecretManagementClientException from
     * SecretConstants.ErrorMessages object when no exception is thrown.
     *
     * @param error SecretConstants.ErrorMessages.
     * @param data  data to replace if message needs to be replaced.
     * @return SecretManagementClientException.
     */
    public static SecretManagementClientException handleClientException(SecretConstants.ErrorMessages error,
                                                                        String... data) {

        String message = populateMessageWithData(error, data);
        return new SecretManagementClientException(message, error.getCode());
    }

    public static SecretManagementClientException handleClientException(SecretConstants.ErrorMessages error,
                                                                        String data, Throwable e) {

        String message = populateMessageWithData(error, data);
        return new SecretManagementClientException(message, error.getCode(), e);
    }

    /**
     * This method can be used to generate a SecretManagementServerException from
     * SecretConstants.ErrorMessages object when no exception is thrown.
     *
     * @param error SecretConstants.ErrorMessages.
     * @param data  data to replace if message needs to be replaced.
     * @return SecretManagementServerException.
     */
    public static SecretManagementServerException handleServerException(SecretConstants.ErrorMessages error,
                                                                        String data) {

        String message = populateMessageWithData(error, data);
        return new SecretManagementServerException(message, error.getCode());
    }

    public static SecretManagementServerException handleServerException(SecretConstants.ErrorMessages error,
                                                                        String data, Throwable e) {

        String message = populateMessageWithData(error, data);
        return new SecretManagementServerException(message, error.getCode(), e);
    }

    public static SecretManagementServerException handleServerException(
            SecretConstants.ErrorMessages error, Throwable e) {

        String message = populateMessageWithData(error);
        return new SecretManagementServerException(message, error.getCode(), e);
    }

    public static String generateUniqueID() {

        return UUID.randomUUID().toString();
    }

    public static boolean useCreatedTimeField() {

        return SecretManagerComponentDataHolder.getUseCreatedTime();
    }

    private static String populateMessageWithData(SecretConstants.ErrorMessages error, String... data) {

        String message;
        if (data != null && data.length != 0) {
            message = String.format(error.getMessage(), data);
        } else {
            message = error.getMessage();
        }
        return message;
    }

    private static String populateMessageWithData(SecretConstants.ErrorMessages error) {

        return error.getMessage();
    }

}
